export class UserDto {
     user_id:number;
     name: string;
     email: string;
     phone: string;
     zip_code: string;
     roles: string;
    // Add more fields as needed
  }

  