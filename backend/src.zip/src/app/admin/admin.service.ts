import { Injectable } from '@nestjs/common';
import { SupabaseService } from '../supabase.service';
@Injectable()
export class AdminService {

}
