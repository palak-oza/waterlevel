import { Controller } from '@nestjs/common';

@Controller('admin')
export class AdminController {}
