import { Module } from '@nestjs/common';
import { PredictionController } from './model.controller';
import { ModelService } from './model.service';

@Module({
  controllers: [PredictionController],
  providers: [ModelService],
})
export class PredictionModule {}
