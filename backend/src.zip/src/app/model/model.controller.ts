import { Controller, Get, Param } from '@nestjs/common';
import { ModelService } from './model.service';

@Controller('prediction')
export class PredictionController {
  constructor(private readonly modelService: ModelService) {}

  @Get(':inputData')
  async predict(@Param('inputData') inputData: number): Promise<any> {
    return this.modelService.predict(inputData);
  }
}
