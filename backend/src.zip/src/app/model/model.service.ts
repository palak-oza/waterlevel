import { Injectable } from '@nestjs/common';
import * as p from 'node-pickle';

@Injectable()
export class ModelService {
  async predict(inputData: number): Promise<any> {
    try {
      // Load the machine learning model (pickle file)
      const model = p.load('assets/arima_model.pkl');
      // Make prediction using the loaded model and input data
      const prediction = await model.predict(inputData);
      return prediction;
    } catch (error) {
      // Handle errors appropriately
      console.error('Error predicting:', error);
      throw error; // Or handle it gracefully based on your requirements
    }
  }
}
