
export class SensorDto {
    srno: number;
    sensor_name: string;
    distance_cm: number;
    timestamp: Date;
    litre:number;
  }